(function($){

	FLBuilder.registerModuleHelper('pricing_table_column_form', {

        init: function()
		{
			UABBButton.init();
		},
    });
})(jQuery);