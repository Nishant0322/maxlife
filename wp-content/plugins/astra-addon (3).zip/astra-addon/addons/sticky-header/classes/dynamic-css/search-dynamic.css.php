<?php
/**
 * Sticky Header Social Dynamic CSS
 *
 * @package Astra Addon
 */

add_filter( 'astra_dynamic_css', 'astra_sticky_header_search_dynamic_css' );

/**
 * Dynamic CSS
 *
 * @param  string $dynamic_css          Astra Dynamic CSS.
 * @param  string $dynamic_css_filtered Astra Dynamic CSS Filters.
 * @return string
 */
function astra_sticky_header_search_dynamic_css( $dynamic_css, $dynamic_css_filtered = '' ) {

	$selector = '.ast-header-sticked .ast-header-search';

	/**
	 * Search CSS.
	 */
	$css_output_desktop = array(

		$selector . ' .astra-search-icon, ' . $selector . ' .ast-search-menu-icon .search-field::placeholder' => array(
			'color' => esc_attr( astra_get_option( 'sticky-header-search-icon-color' ) ),
		),
		$selector . ' .ast-search-menu-icon .search-field, ' . $selector . ' .ast-search-menu-icon .search-form, ' . $selector . ' .ast-search-menu-icon .search-submit ' => array(
			'background-color' => esc_attr( astra_get_option( 'sticky-header-search-box-background-color' ) ),
		),
	);
	/* Parse CSS from array() */
	$css_output = astra_parse_css( $css_output_desktop );

	$dynamic_css .= $css_output;

	return $dynamic_css;

}
