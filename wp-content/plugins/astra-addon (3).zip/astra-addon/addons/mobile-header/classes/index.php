<?php
/**
 * Index file
 *
 * @package Astra Addon
 * @since Astra 1.4.0
 */

/* Silence is golden, and we agree. */
